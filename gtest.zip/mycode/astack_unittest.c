/* 
 * File : astack_unittest.c  Date: 2017-03-09
 * ========================================
 * get start with gtest work
 */

#include <limits.h>
#include "astack.h"
#include "gtest/gtest.h"

TEST (StackTest , dofun){
  item in,out;
  in.x = 1;
  in.y = 2;

  initialize();
  
  EXPECT_EQ( isEmpty() , 1);
  
  push(in);
  EXPECT_EQ( isEmpty() , 0);

  pop(&out);
  EXPECT_EQ( isEmpty() , 1);

  EXPECT_EQ( in.x , out.x);
  EXPECT_EQ( in.y , out.y);
  clearStack();
}

TEST (StackOrderTest, poporder){
  item in[3],out[3];
  int i;

  initialize();

  for (i = 0; i < 3; i++) {
    in[i].x = i;
    in[i].y = in[i].x + 1;
    
    push(in[i]);
  }  

  for (i = 2; i >=0 ; i--) {
    pop(&(out[i]));
  }

  EXPECT_EQ( in[0].x , out[0].x);
  EXPECT_EQ( in[0].y , out[0].y);
  EXPECT_EQ( in[1].x , out[1].x);
  EXPECT_EQ( in[1].y , out[1].y);
  EXPECT_EQ( in[2].x , out[2].x);
  EXPECT_EQ( in[2].y , out[2].y);
  clearStack();
}
  
TEST (StackResizeTest , resize) {
  item in[32], out[32];
  int i;

  initialize();
  for ( i = 0 ; i < 32 ; i++) {
    in[i].x = i;
    in[i].y = i + 100;
    
    push(in[i]);
  }
  
  for ( i = 31 ; i >= 0 ; i--) {
    pop(&(out[i]));
    
    EXPECT_EQ( out[i].x , in[i].x );
    EXPECT_EQ( out[i].y , out[i].y );
  }
  
  clearStack();
}

TEST (StackLimitDeathTest , noInit) {
  item in,out;
  in.x=1;
  in.y=2;
  
  testing::FLAGS_gtest_death_test_style = "fast";
  EXPECT_EXIT(pop(&out), testing::ExitedWithCode(1),"Error.*");
  
  EXPECT_EXIT(push(in), testing::ExitedWithCode(1), "Error.*");
  
  EXPECT_DEATH(push(in) , "");
  EXPECT_DEATH(pop(&out), "");
}
